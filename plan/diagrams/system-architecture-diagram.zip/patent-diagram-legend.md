# Figure 1 - System Architecture Legend

## Input Sources (10)

| Element | Description |
|---------|-------------|
| 11 | Photo Input |
| 12 | Drawing Input |
| 13 | Text Input |
| 14 | Speech Input |

## Processing System (20)

| Element | Description |
|---------|-------------|
| 21 | Input Module |
| 22 | AI Interpretation Module |
| 23 | DSL Generator |
| 24 | Validation Module |
| 25 | Animation Generator |
| 26 | Video Renderer |
| 27 | Output Module |

## Output Types (30)

| Element | Description |
|---------|-------------|
| 31 | Image Output |
| 32 | Video Output |

## Data Flow

- Inputs (11-14) feed into Input Module (21)
- Processing proceeds sequentially: 21 → 22 → 23 → 24 → 25 → 26 → 27
- Validation Module (24) returns to DSL Generator (23) on validation failure (dashed line)
- Output Module (27) produces either Image Output (31) or Video Output (32)
